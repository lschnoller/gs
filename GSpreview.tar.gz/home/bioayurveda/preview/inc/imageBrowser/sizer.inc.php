<?
$carpeta[0] = "large";
$carpeta[1] = "small";
$carpeta[2] = "thumbnails";
//$carpeta[3] = "imagenes4";
//$carpeta[4] = "imagenes5";
//$carpeta[5] = "imagenes6";
//$carpeta[6] = "imagenes7";

$titulo[0] = "Large";
$titulo[1] = "Small (Gallery)";
$titulo[2] = "Thumbnails";
//$titulo[3] = "Imagenes 4";
//$titulo[4] = "Imagenes 5";
//$titulo[5] = "Imagenes 6";
//$titulo[6] = "Imagenes 7";

$medidas[0] = "250 x 500 or 300 x 300";
$medidas[1] = "200 x 400 or 200 x 200";
$medidas[2] = "50 x 70";
//$medidas[3] = "";
//$medidas[4] = "";
//$medidas[5] = "";
//$medidas[6] = "";
?>