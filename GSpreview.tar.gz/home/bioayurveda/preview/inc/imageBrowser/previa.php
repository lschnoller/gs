<html>

	<head>

		<title>Image Browser</title>

	</head>

  <body bgcolor="#E5E5E5" topmargin=0 leftmargin=0 rightmargin=0 scroll=yes>

  	<table width="100%" height=100% border=0 cellspacing=0 cellpadding=0>

  		<tr><td align=center>

  		<?

 		  

    	if(isset($_GET['path'])){

    	  echo "<img src=\"http://localhost/gs/images/quickLinks/" . $_GET['file']."\" border=0>";

  	  }

  	  ?>

  		</td></tr>

  	</table>

  </body>

</html>