var anylinkmenu1={divclass:'anylinkmenu', inlinestyle:'', linktarget:''}; //First menu variable. Make sure "anylinkmenu1" is a unique name!
anylinkmenu1.items=[
	["QUÉ ES EL MBA?", "http://biodinamica-ayurveda.com/mba"],
	["TECNICAS DE MEDITACION", "http://biodinamica-ayurveda.com/ayurveda/meditacion"],
	["MASAJE AYURVEDICO", "http://biodinamica-ayurveda.com/ayurveda/masaje"],
	["EL CAMINO DEL INSTRUCTOR", "http://biodinamica-ayurveda.com/ayurveda/instructorado"]
];
var anylinkmenu2={divclass:'anylinkmenu', inlinestyle:'', linktarget:''}; //First menu variable. Make sure "anylinkmenu1" is a unique name!
anylinkmenu2.items=[
	["COUNSELING", "http://biodinamica-ayurveda.com/servicios/counceling"],
	["CURSOS", "http://biodinamica-ayurveda.com/servicios/cursos"],
	["SEMINARIOS", "http://biodinamica-ayurveda.com/servicios/seminarios"],
	["TRATAMIENTOS Y", "http://biodinamica-ayurveda.com/"]
];
var anylinkmenu3={divclass:'anylinkmenu', inlinestyle:'', linktarget:''}; //First menu variable. Make sure "anylinkmenu1" is a unique name!
anylinkmenu3.items=[
	["FORMACIÓN A DISTANCIA", "http://biodinamica-ayurveda.com/actividades/cursos_a_distancia"],
	["PUBLICACIONES Y NOTICIAS", "http://biodinamica-ayurveda.com/"],
	["CALENDARIO DE ACTIVIDADES", "http://biodinamica-ayurveda.com/actividades/calendario"],
	["ENLACES RELACIONADOS", "http://biodinamica-ayurveda.com/actividades/charlas_talleres"]
];