<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		
		<div>
   			
   			<div class="left list">
   				<h1 class="orange2">Curso de Verano</h1>
   				<p class="green">Masaje Shantala </p>
   				<p>Duración: 1 Jornada</p>
   				<p><b>Sábado 23 de Enero, de 9.30 a 17 hs.</b></p>	
   				
   			</div>
   			<div class="right">
   				<h1 class="orange2">Procedimientos Ayurvédicos</h1>
   				<p class="green">Cierre de inscripción: 23 de Abril</p>
   				<p>Pre-requisito: Curso Básico de Masaje.</p>
   				<p><b>Primer sábado de cada mes, de 9.30 a 17.30 hs.</b></p>
   				<div id="call-box">
   					Para reservar una entrevista o saber más,<br>
   					llámenos al <b>4822-3498 o 4821-6721</b>,<br> 
					de lunes a viernes, de 14 a 19 horas.
   				</div>
   			</div>
   		</div>   		
			
   	</div>
   </div>
       
</div>