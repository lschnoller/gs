<style>
<!--
#top-image-home{
	width: 950px;
	height: 248px;
	position: relative;
	background-repeat:no-repeat;
	font-family: "Century gothic";
	color: #fff;
}
.home-big{
	background-image: url("design/home-big.jpg");
}
.home-big h1{
	font-size: 22px;
	margin-left: 100px;
	padding-top: 100px;
}
.home-menu{
	background-image: url("design/home-menu.png");
	background-repeat:no-repeat;
	width: 889px;
	height: 221px;
	position: absolute;
	top: 200px;
	left: 30px;
}
.home-menu h1{
	font-family: "Century Gothic";
	font-size: 	23px;
	margin: 0;padding: 0;
	margin-top: 5px;
}
.home-menu a{
	font-family: "Century Gothic";
	font-size: 	12px;
	color: #5B6F05;
	margin: 0;padding: 0;
	margin-top: 15px;
	display: block;
	text-decoration: none;
}
.home-menu a:HOVER{
	color: #FF9900;
}
.menu-alt{
	text-align: center;
	width: 283px;
	float: left;
}
-->
</style>
<div id="bd">
   <div id="yui-main">
   		<div id="top-image-home" class="home-big">
   			<h1>Un espacio para el bienestar, la salud <br>y la belleza duradera.</h1>
   			<div class="home-menu">
   				<div class="menu-alt">
   					<h1>MÉTODO</h1>
   					<a href="<?php echo base_url();?>mba">QUÉ ES EL MBA?</a>
   					<a href="<?php echo base_url();?>ayurveda/meditacion">TÉCNICAS DE MEDITACIÓN</a>
   					<a href="<?php echo base_url();?>ayurveda/masaje">MASAJE AYURVÉDICO</a>
   					<a href="<?php echo base_url();?>ayurveda/instructorado">EL CAMINO DEL INSTRUCTOR</a>
   				</div>
   				
   				<div class="menu-alt" style="margin-left: 20px;">
   					<h1>SERVICIOS</h1>
   					<a href="<?php echo base_url();?>servicios/counceling">COUNSELING</a>
   					<a href="<?php echo base_url();?>servicios/cursos">CURSOS</a>
   					<a href="<?php echo base_url();?>servicios/seminarios">SEMINARIOS</a>
   					<a href="<?php echo base_url();?>servicios/">TRATAMIENTOS Y COSMÉTICA</a>
   				</div>
   				
   				<div class="menu-alt" style="margin-left: 20px;">
   					<h1>ACTIVIDADES</h1>
   					<a href="<?php echo base_url();?>actividades/cursos_a_distancia">FORMACIÓN A DISTANCIA</a>
   					<a href="<?php echo base_url();?>actividades/">PUBLICACIONES Y NOTICIAS</a>
   					<a href="<?php echo base_url();?>actividades/calendario	">CALENDARIO DE ACTIVIDADES</a>
   					<a href="<?php echo base_url();?>actividades/charlas_talleres">ENLACES RELACIONADOS</a>
   				</div>
   			</div>
   		</div>
   	<div id="content" style="margin-top: 200px;">
   		<div>
   			<div class="three">
				<a href="<?php echo base_url();?>mba"><h2 class="orange2" style="padding-left: 30px;margin-top: 0;">QUÉ ES</h2>
   				<h2 class="orange2" style="margin-top: 0;">EL MÉTODO</h2>
         		<h2 class="orange2" style="padding-left: 50px;margin-top: 0;">BIODINÁMICA</h2>
         		<h2 class="orange2" style="margin-top: 0;">AYURVEDA</h2></a>
			</div>
   			<div class="three">
				<p>Para facilitar tu autoconocimiento hemos desarrollado el Método Biodinámica Ayurveda. Desde este enfoque, te brindamos numerosas actividades para acompañar tu camino hacia el equilibrio físico y energético, liberación emocional y desarrollo espiritual. </p>
   			</div>
   			<div class="three">
				<p>Nuestros programas incluyen counseling individual, técnicas de meditación, masaje Ayurveda, tratamientos holísticos, cursos, talleres temáticos y capacitación de instructores. </p>
   			</div>
   		</div>
   	</div>
   </div>
   
</div>