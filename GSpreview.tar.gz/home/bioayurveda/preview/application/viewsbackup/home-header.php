<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title;?></title>
<link rel="stylesheet" href="<?php echo base_url();?>css/reset-fonts-grids.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url();?>css/layout.css" type="text/css">


</head>

<body class="yui-skin-sam">
   <div id="doc2" class="yui-t3">
   	<div id="hd" style="height: 134px;">
   		<a id="logo-gs" href="<?php echo base_url();?>"></a>
   		<a id="logo-mba" href="<?php echo base_url();?>mba" style="margin-top: 20px;"></a>
   		<div id="head-left-menu">
   			<ul>
   				<li><a href="<?php echo base_url();?>">INICIO</a></li>
   				<li class="left-border"><a href="<?php echo base_url();?>nuestro_centro">NUESTRO CENTRO</a></li>
   				<li class="left-border"><a href="<?php echo base_url();?>equipo">EQUIPO</a></li>
   				<li class="left-border"><a href="<?php echo base_url();?>contactenos">CONTACTENOS</a></li>
   				<li class="left-border"><a href="">INGRESAR</a></li>
   			</ul>
   		</div>  		
    </div>
