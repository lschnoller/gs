<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		
   		<div>
   			<p>
   				Estos cursos están orientados al estudio y la práctica de las principales técnicas del método desarrollado por 
Graciela Schnöller: la meditación y el masaje.
   			</p>
   			<p>
   			Cada uno de estos programas tiene como principal objetivo facilitar el desarrollo personal y el conocimiento propio. De acuerdo a nuestro enfoque personalizado, se dictan de forma individual o en grupos pequeños.
   			</p>
   			<p>
   				<a class="sub-link" href="#">TÉCNICAS DE MEDITACIÓN</a>
   				<a class="sub-link" href="#" style="margin-left: 20px;">MASAJE AYURVÉDICO</a>
   			</p>
   		</div>
   		<div>
   			
   		</div>
		<div>
   			
   			<div class="left list">
   				<h1 class="orange2">MASAJE AYURVÉDICO</h1>
   				<p></p>
   				<p class="grey">El masaje con aceites es una técnica energética y armonizadora. Vigoriza los tejidos del cuerpo físico permitiendo disolver bloqueos, aliviar dolores y corregir la postura. El Masaje Ayurvédico es holístico, por lo tanto, armoniza cuerpo-psiquis-mente, descubriendo la belleza sutil. </p>
   				<h1 class="orange2">INTRODUCCIÓN AL MASAJE AYURVEDICO</h1>	
   				<h2 class="green">Curso Básico Intensivo</h2>
   				<p>En este curso teórico-práctico podrás disfrutar de una experiencia renovadora y vivificante. Incorporarás nociones y recomendaciones que te ayudarán a vivir en equilibrio. Aprenderás las maniobras específicas del Masaje Tradicional Ayurvédico y apreciarás sus beneficios. No se necesita experiencia previa.</p>
   				<h2 class="green">Síntesis de los contenidos:</h2>
   				<ul>
	   				<li>El enfoque MBA.</li>
					<li>Principios ayurvédicos.</li>
					<li>Energías elementales.</li>
					<li>Test del biotipo constitucional.</li>
					<li>Qué caracteriza al Masaje Ayurveda.</li>
					<li>Manipulaciones.</li>
					<li>Beneficios y contraindicaciones. </li>
					<li>Masaje Vata, Pitta y Kapha.</li>
					<li>Puntos marmas.</li>
					<li>Terapias sutiles: Aromas y Aceites. Colores. </li>
	    			<li>Gemas y cristales.</li>
					<li>Automasaje.</li>
   				</ul>	
   				<h2 class="green">Información general</h2>	
   			</div>
   			<div class="right">
   				<h1 class="orange2">MASAJE SHANTALA</h1>
   				<h2 class="green">Curso Básico Grupal</h2>
   				<p class="grey">
   					El Masaje para niños es una práctica que contiene en su sabiduría un propósito: armonizar la mente y el cuerpo, estableciendo un lenguaje sin palabras, para fortalecer una relación emocional entre dos seres. Se basa en caricias maternales que se realizan con un aceite especial.
		 		</p>
		 		<p>
		 			Se dictará el 23 de Enero.
					Duración: 1 Jornada, de 9.30 a 17.30 hs.
					Se entregan certificados.
		 		</p>
		 		
   				<div id="call-box">
   					Para reservar una entrevista o saber más,<br>
   					llámenos al <b>4822-3498 o 4821-6721</b>,<br> 
					de lunes a viernes, de 14 a 19 horas.
   				</div>
   			</div>
   		</div>
			
   	</div>
   </div>
       
</div>