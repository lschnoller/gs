<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
		<div>
   			<div class="left">
   				<p class="grey"><span class="orange">El masaje</span> es una herramienta valiosa a la que recurrimos para facilitar experiencias de autoconocimiento. Mediante el masaje se afloja la tensión producida por el estrés, el control y el temor, posibilitando la relajación integral.</p>
   				<p>En el Ayurveda, el masaje es una técnica auxiliar que se aplica para mantener y mejorar la salud, oxigenar el cuerpo y desarrollar la energía. Forma parte de un estilo de vida que tiene como meta la prevención de dolencias y el desarrollo de la inmunidad natural. </p>
   			</div>
   			<div class="right list">
   				<p class="grey"><span class="orange">El Masaje Ayurvédico</span> consiste en toques sutiles que mediante el contacto con la piel, permite establecer diferentes registros: 
la sensibilidad muscular, las contracturas y el dolor físico. Todas estas realidades, muchas veces son sustitutos de emociones atrapadas, que todavía no se han hecho conscientes.</p>
   				<p>A medida que se van abriendo campos de energía que permiten al cuerpo  alcanzar una armonía interior, se va logrando una integración amorosa de cada una de sus partes.</p> 				
   			</div>
   		</div>	
   		<div class="clear"></div>
   		<div class="ayrac-big"></div>
   		<div>
   			
   			<div class="left">
   				<h1 class="orange2">&nbsp;</h1>
   				<h1 class="orange" style="font-size: 20px;padding-left: 30px;margin-top: 0;">Principales</h1>
   				<h1 class="orange" style="font-size: 26px;margin-top: 0;">beneficios de</h1>
         		<h1 class="orange" style="font-size: 20px;padding-left: 50px;margin-top: 0;">masaje ayurbédico</h1>
   				<p class="green">Los beneficios que se obtienen con el masaje son físicos, fisiológicos y psicológicos. </p>
   			</div>
   			<div class="right list">
   				<h1 class="green">Sus múltiples beneficios son:</h1>
   				<ul>
   					<li>Proporciona relajación y mejora la resistencia al estrés.</li>
					<li>Facilita la desintoxicación y el rejuvenecimiento de los tejidos. </li>
					<li>Mejora la flexibilidad de las articulaciones.</li>
					<li>Alivia los dolores reumáticos.</li>
					<li>Promueve el buen funcionamiento de los órganos y de los sistemas digestivo, circulatorio, respiratorio y excretor.</li>
					<li>Produce bienestar, calma y claridad mental.</li>
					<li>Demora el envejecimiento.</li>
					<li>Reduce el cansancio, la depresión, la ansiedad.</li>
					<li>Mejora la capacidad de comunicación.</li>
   				</ul>				
   			</div>
   		</div>
   	</div>
   </div>    
</div>