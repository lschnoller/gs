<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<p>
   			
   		</p>
   		
   		<div>
   			<div class="left">
   				<p class="grey">
   				<span class="orange">La meditación como sistema</span> es parte de la tradición Yoga de la India. Para el Ayurveda, es una herramienta de autoconocimiento, que auxilia al practicante a identificar el origen de sus problemas actuales y resolverlos.
   				</p>
   				<p class="grey">
   				<span class="orange">La meditación ayuda</span> a reflexionar a fondo sobre uno mismo, estableciendo un puente entre cuerpo-mente-alma. Así se logra la perfecta salud, que se obtiene al lograr el equilibrio interior. 
   				</p>
   			</div>
   			<div class="right">
   				<p class="grey">
   				<span class="orange">La meditación es conciencia,</span> es tu naturaleza, es tu mismo ser. Sin embargo, para comenzar, se necesita una técnica que indique el camino, que ayude a llegar a una visión clara “sin esfuerzo”.
   				</p>
   				<p class="grey">
   				<span class="orange">La  Meditación Biodinámica,</span> uno de los  pilares del MBA, es un abordaje de la práctica meditativa y un acompañamiento en el proceso de purificación de la mente. Con esta técnica, la persona aprende primero a relajarse de manera consciente, para que sus contenidos internos puedan integrarse y acceder a la verdadera identidad.
   				</p>
   			</div>
   		</div>
   		<div class="clear"></div>
		<div class="ayrac-big"></div>
		<div>
   			<div class="left">
   					<h1 class="orange" style="font-size: 20px;padding-left: 30px;margin-top: 0;">Principales</h1>
   					<h1 class="orange" style="font-size: 26px;margin-top: 0;">beneficios de</h1>
         			<h1 class="orange" style="font-size: 20px;padding-left: 50px;margin-top: 0;">la meditación</h1>
   				<p class="green">
   					La meditación, a través de un proceso de autoconocimiento, nos ayuda a redescubrirnos abriendo una puerta a infinitas posibilidades. 
   				</p>
   			</div>
   			<div class="right list">
   				<h2 class="green">Sus múltiples beneficios son:</h2>
   				<p></p>
   				<ul>
   					<li>Facilita la relajación, reduciendo el estrés y la ansiedad.</li>
   					<li>Induce a hábitos de salud más positivos. </li>
   					<li>Promueve la sabiduría emocional.</li>
   					<li>Rejuvenece y revitaliza.</li>
   					<li>Reduce la incidencia de enfermedades</li>
   					<li>cardiovasculares. Mejora el rendimiento laboral. </li>
					<li>Incrementa la creatividad y la claridad mental.</li>
					<li>Afirma la identidad y la autoestima. </li>
					<li>Conduce a la liberación interior y a la realización personal</li>
   				</ul>   				
   			</div>
   		</div>
			
   	</div>
   </div>
       
</div>