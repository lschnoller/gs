<style>
<!--
#content h1,#content h2{
	margin-top: 5px;
}
-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<div>
   			<div class="left">
   				<h2 class="orange">El Centro Graciela Schnöller te da la bienvenida!</h2>
   				<p class="grey">
   				Desde hace más de dos décadas estamos comprometidos con nuestra misión: el bienestar integral que logramos cuando nos conectamos con nuestro verdadero ser.  </p>
   				<p class="grey">Para facilitar tu autoconocimiento hemos desarrollado el Método Biodinámica Ayurveda. Desde este enfoque, te brindamos numerosas actividades para acompañar tu camino hacia el equilibrio físico y energético, liberación emocional y desarrollo espiritual.  </p>
   				<p class="green">Nuestros programas incluyen counseling individual, técnicas de meditación, masaje Ayurveda, tratamientos holísticos, cursos, talleres temáticos y capacitación  </p>
   			</div>
   			<div class="right">
   				<h2>&nbsp;</h2>
   				<p class="grey">A través de nuestras diferentes actividades y procedimientos proporcionamos  herramientas que facilitan hábitos de vida más saludables y una belleza duradera. Sabemos que para cada uno de nosotros, esta experiencia es un viaje personal.</p>
   				<p class="orange">En el CGS ayudamos a cada individuo a encontrar su propio sendero. En una atmósfera que abraza la esencia de la serenidad y el rejuvenecimiento te invitamos a descubrir tu propia naturaleza para vivir en plenitud. </p>
   			</div>
   		</div>
   		<div class="clear"></div>
   		<div class="ayrac-big"></div>
   		<div>
   			<div class="left" style="width: 150px;"><img src="<?php echo base_url();?>design/gs-photo.png"/></div>
   			<div class="right" style="width: 650px;">
   				<p><b>Graciela Schnöller</b>, Directora del Centro, es autora del <span class="orange">Método Biodinámica Ayurveda®.</span> Desde esta visión plantea  una convergencia entre el misticismo oriental y la concepción integradora del ser humano, adoptada por especialidades occidentales de reciente desarrollo. </p>
   				<p>A lo largo de su carrera profesional presentó trabajos científicos, artículos y numerosas notas en medios gráficos. Participó en diversos programas televisivos, de radio y como disertante en Congresos Nacionales e Internacionales. </p>
   				<p style="text-align: right;"><a class="sub-link">mas...</a></p>
   			</div>
   		</div>
   	</div>
   </div>
       
</div>