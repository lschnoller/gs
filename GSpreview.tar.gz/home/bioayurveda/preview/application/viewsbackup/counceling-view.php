<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		
		<div>
   			
   			<div class="left list">
   				<h1 class="orange2">Consulta Psicológica</h1>
   				<p></p>
   				<p class="grey">El Counseling Psicológico es una relación de ayuda orientada a personas que dentro de un marco de normalidad  viven situaciones difíciles en lo cotidiano. </p>
   				<p>En la consulta construimos un vínculo de confianza invitando a la autoexploración. El objetivo es que puedas conectarte con tus propios recursos para destrabar conflictos, atravesar </p>
   				<div id="call-box">
   					Para reservar una entrevista o saber más,<br>
   					llámenos al <b>4822-3498 o 4821-6721</b>,<br> 
					de lunes a viernes, de 14 a 19 horas.
   				</div>
   			</div>
   			<div class="right">
   				<h1 class="orange2">&nbsp;</h1>
   				<p class="grey">Nuestra modalidad se fundamenta en la orientación psicoeducativa  de Carl Rogers, que considera que el ser humano está dotado de todas las potencialidades necesarias para su completo desarrollo. </p>
		 		<p>
Iniciar un proceso de acompañamiento desde el Counseling te facilitará un espacio en donde puedas sentirte verdaderamente libre y seguro como para aventurarte a ser tú mismo.</p>
		 		<h2 class="orange" style="margin-top: 25px;text-align: center;font-size: 15px;">CONSULTÁ COUNSELING AYURVÉDICO<br>aquí</h2>
   				
   			</div>
   		</div>	
   	</div>
   </div>    
</div>