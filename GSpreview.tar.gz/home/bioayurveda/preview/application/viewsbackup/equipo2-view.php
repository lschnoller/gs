<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<div>
   			<p>
   				<a class="sub-link" href="#">GRACIELA SCHNÖLLER</a>
   				<a class="sub-link" href="#">ERIKA SCHNÖLLER</a>
   				<a class="sub-link" href="#">NOS ACOMPAÑAN ESTE AÑO...</a>
   				<a class="sub-link" href="#">ASISTENTES</a>
   			</p>
   		</div>
   		<div><h2>&nbsp;</h2></div>
   		<div>
   			<div class="left" style="width: 200px;">
   				<img alt="ERIKA SCHNÖLLER" src="<?php echo base_url();?>design/erika-photo.png">
   				<h2 class="orange">ERIKA SCHNÖLLER</h2>
   			</div>
   			<div class="right list" style="width: 600px;">
   				<h2 class="green">Counseling <span class="grey" style="font-size: 13px;">Consultoría Psicológica</span></h2>
   				<p class="grey">Realicé mis estudios como Counselor en Holos Capital,  en el enfoque centrado en la persona de Carl Rogers. 2009.</p>
   				<p>Hoy trabajo de manera privada en consultorio, coordino seminarios y  talleres vivenciales con distintas temáticas, e integro mis conocimientos a todas las actividades que brindamos desde nuestro método MBA.</p>
   				<h2 class="green">Consultoría en Ayurveda</h2>
   				<p>Obtuve mi Certificado por el Dr. David Frawley en el American Institute of Vedic Studies. Nuevo Méjico, EEUU.  2007</p>
   				<h2 class="green">Yogaterapia</h2>
   				<p>Formación en Integrative Yoga Therapy®. Profesora Carmen Ferreto.</p>
   				<h2 class="green">Educación. <span class="grey" style="font-size: 13px;">Docencia</span></h2>
   				<p>Realicé mis estudios de Profesorado de Inglés en el Instituto Superior en Lenguas Vivas. </p>
   				<p>Ejercí la docencia desde 1996. Instituciones en las que me desempeñé: Colegio María Auxiliadora. Colegio del Arce. Colegio San Martín de Tours. St. Mark’s School. Dansey & Wesley Institute (Business English In-Company).</p>
   				<p><span class="orange">A cargo de las siguientes actividades en nuestro Centro:</span> Servicio de Counseling. Cursos a distancia. Seminario de  Estrés y Ayurveda. Seminario de Sexualidad y Espiritualidad femenina. Cursos MBA en empresas. </p>
   			</div>
   		</div>
   		
   	</div>
   </div>
       
</div>