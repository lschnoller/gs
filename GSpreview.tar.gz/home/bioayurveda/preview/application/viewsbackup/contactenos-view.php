<style>
<!--
.cleft{
	float: left;
	width: 200px;
	text-align: right;
	margin-top: 10px;
}
.cright{
	float: left;
	text-align: right;
	margin-left: 10px;
	margin-top: 10px;
}
.cright input{
	width: 500px;
	border: solid 1px #E8E8E8;
	padding: 7px;
	-moz-border-radius: 1em;
	color:#333333;
}
.cright textarea{
	color:#333333;
	width: 500px;
	height: 250px;
	border: solid 1px #E8E8E8;
	padding: 7px;
	-moz-border-radius: 1em;
}
-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		
   		<?php 
   			if($send){
   				echo '<h1>El mensaje ha sido enviado. Graicas por comunicarse con nosotros.</h1>';
   			}else{
   		?>
   		<?php echo form_open(base_url().'contactenos'); ?>
   		<div>
   			<div class="cleft green">Nombre :</div>
   			<div class="cright"><input type="text" name="nombre" value="<?php echo set_value('nombre'); ?>" /></div>
   		</div>
   		<div class="clear"></div>
   		<div>
   			<div class="cleft green">Asunto :</div>
   			<div class="cright"><input type="text" name="asunto" value="<?php echo set_value('asunto'); ?>" /></div>
   		</div>
   		<div>
   			<div class="cleft green">Email :</div>
   			<div class="cright"><input type="text" name="email" value="<?php echo set_value('email'); ?>" /></div>
   		</div>
   		<div class="clear"></div>
   		<div>
   			<div class="cleft green">Mensaje :</div>
   			<div class="cright"><textarea name="mensaje"><?php echo set_value('mensaje'); ?></textarea></div>
   		</div>
   		<div class="clear"></div>
   		<div class="orange" style="margin-top: 10px;text-align: right;padding-right: 100px;cursor: pointer;" onclick="document.forms[0].submit();">Enviar</div>
   		</form>
   		<?php }?>
   		<div><p style="text-align: center;">
   		Paraguay 3474 P.B. (Capital Federal, Buenos Aires, Argentina)  | tel:  4822-3498 . 4821-6721
   		</p>
   		<p> </p></div>
   	</div>
   </div>
       
</div>