<style>
<!--
#content h1,#content h2{
	margin-top: 5px;
}
-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<h1 class="orange" style="margin-left: 200px;">Método Biodinámica ayurveda</h1>
   		<h2 class="green" style="margin-left: 250px;">es un nuevo concepto en capacitación que combina la esencia</h2>
   		<h2 class="green" style="margin-left: 100px;">del Ayurveda y del Yoga con la contribución de modernos enfoques científicos.</h2>
   		<p>
   			
   		</p>
   		
   		<div>
   			<div class="left">
   				<p class="grey">
   				Trabajamos con herramientas específicas, como la meditación y el masaje holístico, que constituyen los principales pilares del MBA. Estas técnicas dinámicas y de autoconocimiento facilitan un proceso experimental valiosísimo. 
   				</p>
   				<p class="grey">El MBA propone, mediante un aprendizaje integral, una forma innovadora de facilitar los procesos individuales y el desarrollo personal. Este enfoque también ofrece abordajes grupales, incluye cursos, seminarios y capacitación de instructores. 
   				</p>
   			</div>
   			<div class="right">
   				<p class="grey">Desde el MBA acompañamos a las personas para que a partir de la propia experiencia, puedan ir desplegando todo su potencial. Al ir relacionando los diferentes planos del ser: físico, emocional, intelectual, espiritual, las ayudamos a considerar todos sus aspectos.</p>
   				<p class="grey">La transformación que van experimentando los practicantes mediante el MBA, es un proceso captado momento a momento, que conduce hacia la Fuente de la alegría y la abundancia.
   				</p>
   			</div>
   		</div>
   		
   	</div>
   </div>
       
</div>