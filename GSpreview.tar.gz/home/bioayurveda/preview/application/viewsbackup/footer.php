      <div id="ft" class="loading">
      	<div id="foot-links">
		     <table width="100%" align="center">
		  	 	<tr>
		      		<td align="center"><img src="<?php echo base_url();?>/design/SEMINARIOS.png"/><br/><a href="#">TRATAMIENTOS</a></td>
		        	<td align="center"><img src="<?php echo base_url();?>/design/SEMINARIOS.png"/><br/><a href="#">TRATAMIENTOS</a></td>
		        	<td align="center"><img src="<?php echo base_url();?>/design/SEMINARIOS.png"/><br/><a href="#">TRATAMIENTOS</a></td>
		      	</tr>
   			</table>
      	</div>
      </div>
   </div>

<script type="text/javascript">
</script>
</body>
</html>
