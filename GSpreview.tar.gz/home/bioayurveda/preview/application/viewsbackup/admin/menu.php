<div id="main-menu">
	<a href="<?php echo base_url();?>admin/calendario">Calendario</a><br>
	<a href="<?php echo base_url();?>admin/quickLinks">QuickLinks</a><br>
	<a href="<?php echo base_url();?>admin/references">References</a><br>
	<a href="<?php echo base_url();?>admin/Talleres">Talleres</a><br>
	<a href="<?php echo base_url();?>admin/seminarioscat">SeminariosCat</a><br>
	<a href="<?php echo base_url();?>admin/seminarios">Seminarios</a><br>
	<a href="<?php echo base_url();?>admin/seminarioscat">SeminariosCat</a><br>
	<a href="<?php echo base_url();?>admin/addresses">Addresses</a><br>
	<a href="<?php echo base_url();?>admin/users">Users</a><br>
</div>