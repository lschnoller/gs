<script>

   (function() {
	    
	    var myConfig = {
	        height: '100px',
	        width: '400px',
	        dompath: false,
	        //focusAtStart: true,
			  handleSubmit: true,
			  toolbar: {
				  //titlebar: 'My Editor',
				  buttons: [
						{ group: 'textstyle',
							 buttons: [
								  { type: 'push', label: 'Bold', value: 'bold' },
								  { type: 'push', label: 'Italic', value: 'italic' },
								  { type: 'push', label: 'Underline', value: 'underline' }
								 
							 ]
						}
				  ]
			 }

	    };

	    var myEditor = new YAHOO.widget.SimpleEditor('desci', myConfig);
	    myEditor.render();

	})();

</script>
</body>
</html>