      
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<p class="grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lacinia molestie quam, vitae rhoncus tortor mollis id. Suspendisse potenti. Proin congue, nulla non volutpat pretium, mi dui tempor eros, ac laoreet lorem felis eget eros. Vivamus pharetra libero sed massa mollis ultricies. Vivamus nec magna et ante elementum convallis at sit amet ante. Fusce massa est, viverra id ultrices in,</p>
   		<p class="grey">consequat in nisi. Donec nibh nulla, scelerisque at rutrum vel, imperdiet sit amet arcu. Suspendisse a pulvinar erat. Sed sit amet ante purus. Aenean tempus sagittis arcu, sed cursus quam ornare a. </p>
   		<p>
   			<a class="sub-link" href="#">Link 1</a>
   			<a class="sub-link" href="#" style="margin-left: 20px;">Link 2</a>
   		</p>
   		
   		<div>
   			<div class="left">
   				<h1 class="orange">header left</h1>
   				<p class="grey">consequat in nisi. Donec nibh nulla, scelerisque at rutrum vel, imperdiet sit amet arcu. Suspendisse a pulvinar erat. Sed sit amet ante purus. Aenean tempus sagittis arcu, sed cursus quam ornare a. </p>
   			</div>
   			<div class="right">
   				<h1 class="orange">header right</h1>
   				<p class="grey">consequat in nisi. Donec nibh nulla, scelerisque at rutrum vel, imperdiet sit amet arcu. Suspendisse a pulvinar erat. Sed sit amet ante purus. Aenean tempus sagittis arcu, sed cursus quam ornare a. </p>
   				<p class="grey">consequat in nisi. Donec nibh nulla, scelerisque at rutrum vel, imperdiet sit amet arcu. Suspendisse a pulvinar erat. Sed sit amet ante purus. Aenean tempus sagittis arcu, sed cursus quam ornare a. </p>
   			</div>
   		</div>
   		
   	</div>
   </div>
       
</div>