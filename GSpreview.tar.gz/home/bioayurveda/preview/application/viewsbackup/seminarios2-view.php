<style>
<!--

-->
</style>
<div id="bd">
   <div id="yui-main">
   	<div id="content">
   		<div>
   			<p>
   				<a class="sub-link" href="#">VITALIDAD</a>
   				<a class="sub-link" href="#">EMOCIONES</a>
   				<a class="sub-link" href="#">ESPIRITUALIDAD</a>
   			</p>
   		</div>
		<div>
   			
   			<div class="left">
   				<p class="grey"><span class="green">Estos talleres y seminarios están destinados principalmente a los estudiantes e instructores pertenecientes al grupo MBA,</span> también, a personas interesadas en aprender como tomar elecciones saludables en su estilo de vida. Cada uno tiene como objetivo avanzar en el autoconocimiento a través de la práctica meditativa.</p>
   				<p>Nuestra intención es ayudar a desarrollar la sensibilidad, optimizar la comunicación y facilitar la organización de encuentros orientados a la prevención y al bienestar. Estas actividades se dictan en diferentes modalidades.  </p>
   			</div>
   			<div class="right list">
   				<h2 class="green">Incluyen instrucción en las siguientes temáticas:</h2>
   				<ul>
   					<li>Reducción y manejo del estrés.</li>
					<li>Desintoxicación, purificación y rejuvenecimiento.</li>
					<li>Nutrición equilibrada y cuidados para mantener la salud y la belleza.</li>
					<li>Transformación emocional.</li>
					<li>Desarrollo de la confianza en uno mismo.</li>
					<li>Meditación para crear relaciones enriquecedoras y saludables.</li>
   				</ul>   				
   			</div>
   		</div>	
   		<div class="clear"></div>
   		<div class="ayrac-big"></div>
   		<div>
   			
   			<div class="left">
   				<h1 class="orange2">EMOCIONES</h1>
   				<p class="green">La meditación establece un puente entre consciente e inconsciente. De esta manera,  cuando aprendemos a ver nuestras fortalezas y debilidades, nos ayuda a descubrir nuestro camino hacia la integración y la  totalidad.</p>
   				<p>Cada uno de estos talleres te permitirá catalizar cambios positivos en la relación que tienes contigo mismo, con los miembros de tu familia, tus amigos y tu entorno. Participarás en ejercicios y técnicas introspectivas específicas, para liberar emociones y transformar tus pensamientos sobre tu propósito de vida, accediendo a la dicha y a la liberación interior.</p>
   				<h2 class="orange2">SABIDURÍA EMOCIONAL</h2>
   				<p class="green2">Cómo influyen las emociones en nuestra vida.</p>
   				<p>Tomar conciencia es el primer paso esencial para cualquier transformación. El objetivo de este taller es ayudarte a desenmascarar aspectos profundos de ti mismo que pueden sabotear tus relaciones, logros y sueños. Te invitamos a aprender como terminar con emociones tóxicas que obstaculizan tu autorrealización profunda.</p>
				<p>El encuentro con la sombra o sea con aquellos aspectos de nuestra naturaleza que rechazamos, nos permite superar el estancamiento emocional que detiene nuestro flujo vital, tensiona nuestro cuerpo y nos impide alcanzar una auto-aceptación genuina.</p>
   			</div>
   			<div class="right list">
   				<h1 class="orange2">&nbsp;</h1>
   				<h2 class="orange2">EL PODER DE LA AUTOESTIMA</h2>
   				<p class="green2">Guía práctica para la superación personal.</p>
   				<p>Todos tenemos en el interior sentimientos no resueltos, que nos llevan a perder la confianza y a desconocer nuestras propias posibilidades. Si no logramos ser auténticos y congruentes con nosotros mismos, es muy probable que tengamos que enfrentarnos a sufrimientos tales como,  psicológicas e insatisfacciones.</p>
   				<p>Este seminario te ayudará a recuperar la autoestima, o sea, a fortalecer la forma de percibirte y de valorarte, para que puedas crear un mundo de amor y de celebración en todas las circunstancias de la vida.</p>
   				<h2 class="orange2">TAROT PSICOLÓGICO</h2>
   				<p class="green2">Introducción a la interpretación y tiradas.</p>
   				<p>Su principal objetivo es enseñar el simbolismo del Tarot desde la perspectiva junguiana y proveer recursos para interpretar el Tarot desde un aspecto terapéutico.</p>
				<p>El inconsciente tiene su lógica propia, distinta a la que conocemos. Las imágenes y los símbolos nos ayudan a conocer su lenguaje y a descifrar sus curiosos mensajes.</p>				
   			</div>
   		</div>
   	</div>
   </div>    
</div>