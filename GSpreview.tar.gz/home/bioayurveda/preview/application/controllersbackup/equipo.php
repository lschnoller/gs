<?php
class Equipo extends Controller {

	function Equipo()
	{
		parent::Controller();	
		$this->load->helper('url');	
	}
	
	function index(){
		$hData['title'] = 'GRACIELA SCHNÖLLER';
		$hData['imageCSS'] = 'equipo-big';
		$hData['textOnImage'] = '<h1>Somos un equipo de profesionales especializados en el <br>trabajo con individuos, grupos y organizaciones.</h1>
								<p>Nuestro propósito es mejorar la calidad de vida, apuntar a la prevención y a la <br>resolución de situaciones o crisis vitales que afecten la salud. </p>
								<p>Entendemos la prevención como una manera de evitar conflictos y desequilibrios <br>que traben nuestro desarrollo e impidan nuestro crecimiento. </p>
								';
		$this->load->view('header',$hData);
		$this->load->view('equipo-view');
		$this->load->view('footer');
	}
	function graciela(){
		$hData['title'] = 'GRACIELA SCHNÖLLER';
		$hData['imageCSS'] = 'equipo-big';
		$hData['textOnImage'] = '<h1>Somos un equipo de profesionales especializados en el <br>trabajo con individuos, grupos y organizaciones.</h1>
								<p>Nuestro propósito es mejorar la calidad de vida, apuntar a la prevención y a la <br>resolución de situaciones o crisis vitales que afecten la salud. </p>
								<p>Entendemos la prevención como una manera de evitar conflictos y desequilibrios <br>que traben nuestro desarrollo e impidan nuestro crecimiento. </p>
								';
		$this->load->view('header',$hData);
		$this->load->view('equipo-view');
		$this->load->view('footer');
	}
	function erika(){
		$hData['title'] = 'ERIKA SCHNÖLLER';
		$hData['imageCSS'] = 'equipo-big';
		$hData['textOnImage'] = '<h1>Somos un equipo de profesionales especializados en el <br>trabajo con individuos, grupos y organizaciones.</h1>
								<p>Nuestro propósito es mejorar la calidad de vida, apuntar a la prevención y a la <br>resolución de situaciones o crisis vitales que afecten la salud. </p>
								<p>Entendemos la prevención como una manera de evitar conflictos y desequilibrios <br>que traben nuestro desarrollo e impidan nuestro crecimiento. </p>
								';
		$this->load->view('header',$hData);
		$this->load->view('equipo2-view');
		$this->load->view('footer');
	}
}
